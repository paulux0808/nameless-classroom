# Third-party notices

`THIRD_PARTY.md` is the dependency inventory. When dependencies are installed/vendor-cached for release production, retain their upstream LICENSE files and attribution notices here or in the final distribution credits.
