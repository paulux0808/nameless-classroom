import { readdir } from 'node:fs/promises';
import { spawnSync } from 'node:child_process';
import { join } from 'node:path';

async function walk(dir) {
  const out = [];
  for (const ent of await readdir(dir, { withFileTypes: true })) {
    const p = join(dir, ent.name); if (ent.isDirectory()) out.push(...await walk(p)); else if (/\.(js|mjs)$/.test(ent.name)) out.push(p);
  }
  return out;
}
let failed = false;
const roots = ['../src', '../tools', '../chapters'].map((rel) => new URL(rel, import.meta.url).pathname);
const files = [];
for (const root of roots) files.push(...await walk(root));
for (const file of files) {
  const r = spawnSync(process.execPath, ['--check', file], { encoding: 'utf8' });
  if (r.status !== 0) { failed = true; console.error(file, r.stderr); }
}
process.exitCode = failed ? 1 : 0;
