import { readFile, readdir } from 'node:fs/promises';
import { extname, join } from 'node:path';

const [root, levelArg = '0'] = process.argv.slice(2);
if (!root) throw new Error('Usage: node tools/spoiler-audit.mjs <chapter-source-dir> [spoiler-level]');
const level = Number(levelArg);
const level0 = [
  /atomic bomb/i, /nuclear bomb/i, /\bbomb\b/i, /detonator/i, /detonation/i,
  /implosion lens/i, /explosive lens/i, /fat man/i, /little boy/i, /trinity/i,
  /hiroshima/i, /nagasaki/i, /manhattan project/i, /oppenheimer/i,
];
const files = [];
async function walk(dir) {
  for (const ent of await readdir(dir, { withFileTypes: true })) {
    const p = join(dir, ent.name);
    if (ent.isDirectory()) await walk(p);
    else if (['.js', '.mjs', '.json', '.html', '.txt', '.md'].includes(extname(ent.name))) files.push(p);
  }
}
await walk(root);
const problems = [];
if (level === 0) {
  for (const file of files) {
    const text = await readFile(file, 'utf8');
    for (const rx of level0) if (rx.test(text)) problems.push(`${file}: ${rx}`);
  }
}
if (problems.length) {
  console.error('Direct spoiler audit failed. This is supplementary; semantic/indirect leakage still requires authored QA.');
  problems.forEach(x => console.error(`  ${x}`));
  process.exit(1);
}
console.log(`Direct spoiler audit passed: ${root} (level ${level})`);
