import { readFile } from 'node:fs/promises';

const file = process.argv[2];
if (!file) throw new Error('Usage: node tools/verify-offline.mjs <built.html>');
const text = await readFile(file, 'utf8');
const checks = [
  /<(?:script|img|audio|video|source)[^>]+(?:src|href)\s*=\s*["']https?:\/\//ig,
  /<link[^>]+href\s*=\s*["']https?:\/\//ig,
  /\bfetch\s*\(\s*["']https?:\/\//ig,
  /\bnew\s+(?:WebSocket|EventSource)\s*\(\s*["']https?:\/\//ig,
  /\bnavigator\.sendBeacon\s*\(\s*["']https?:\/\//ig,
  /\bimport\s*\(\s*["']https?:\/\//ig,
];
const hits = checks.flatMap(rx => [...text.matchAll(rx)].map(m => m[0]));
if (hits.length) {
  console.error('Remote runtime dependency detected:');
  for (const hit of [...new Set(hits)]) console.error(`  ${hit}`);
  process.exit(1);
}
console.log(`Offline check passed: ${file}`);
