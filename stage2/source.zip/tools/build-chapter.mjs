import { build } from 'esbuild-wasm';
import { readFile, writeFile, mkdir } from 'node:fs/promises';
import { dirname, resolve } from 'node:path';

const args = process.argv.slice(2);
const dev = args.includes('--dev') || process.env.N2_DEV === '1';
const positional = args.filter((arg) => arg !== '--dev');
const [entryArg, outArg] = positional;
if (!entryArg || !outArg) throw new Error('Usage: node tools/build-chapter.mjs <entry.js> <out.html> [--dev]');
const entry = resolve(entryArg); const out = resolve(outArg);
const result = await build({
  entryPoints: [entry], bundle: true, write: false, format: 'iife', platform: 'browser', target: ['es2022'],
  minify: !dev, sourcemap: false, legalComments: 'inline', charset: 'utf8',
  loader: { '.png': 'dataurl', '.jpg': 'dataurl', '.jpeg': 'dataurl', '.webp': 'dataurl', '.svg': 'dataurl', '.glb': 'dataurl', '.bin': 'dataurl', '.mp3': 'dataurl', '.ogg': 'dataurl', '.wav': 'dataurl' },
  define: { __N2_DEV__: dev ? 'true' : 'false' },
});
let js = result.outputFiles[0].text.replace(/<\/script/gi, '<\\/script');
const template = await readFile(new URL('../templates/chapter.template.html', import.meta.url), 'utf8');
const html = template.replace('/*__BUNDLE__*/', js);
await mkdir(dirname(out), { recursive: true }); await writeFile(out, html);
console.log(`Built ${out} (${Buffer.byteLength(html).toLocaleString()} bytes)`);
