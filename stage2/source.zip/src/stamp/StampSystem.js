import { LockKind, OwnerPriority, PlayerState, StampType } from '../constants.js';
import { invariant } from '../core/assert.js';

export class StampSystem {
  #player; #documents; #sequences; #markers; #events; #camera; #active = null;
  constructor({ player, documents, sequences, markers, events, camera }) {
    this.#player = player; this.#documents = documents; this.#sequences = sequences; this.#markers = markers; this.#events = events; this.#camera = camera;
  }
  get active() { return this.#active; }
  begin({ sequenceId, documentId, stampType, stampObjectId, stampAreaId, sweepId, hooks, chapterCommit }) {
    invariant(!this.#active, 'Stamp already active');
    const doc = this.#documents.require(documentId);
    invariant(doc.stampable, `Document not stampable: ${documentId}`);
    invariant(Object.values(StampType).includes(stampType), `Invalid stamp type: ${stampType}`);
    invariant([PlayerState.INSPECT, PlayerState.FOCUS, PlayerState.FREE].includes(this.#player.state), `Invalid player state for stamp: ${this.#player.state}`);
    this.#active = { sequenceId, documentId, stampType, stampObjectId, stampAreaId, sweepId, hooks, chapterCommit, impactStarted: false, confirmReady: false };
    this.#player.setState(PlayerState.STAMP, sequenceId);
    return this.#prepare();
  }
  async #prepare() {
    const a = this.#active;
    await a.hooks?.pickup?.();
    await a.hooks?.align?.();
    invariant(this.#camera.isSafePose(), 'Unsafe stamp camera pose');
    a.confirmReady = true;
    this.#events?.emit('stamp:ready', { sequenceId: a.sequenceId, documentId: a.documentId, stampType: a.stampType });
  }
  async confirm() {
    const a = this.#active;
    if (!a?.confirmReady || a.impactStarted) return false;
    a.confirmReady = false; a.impactStarted = true;
    const owner = a.sequenceId;
    const documentBeforeImpact = structuredClone(this.#documents.require(a.documentId));
    try {
      await this.#sequences.run({
        id: a.sequenceId,
        owner,
        priority: OwnerPriority.STAMP,
        targetIds: [a.stampObjectId, a.documentId],
        reserveIds: [a.stampAreaId, a.sweepId].filter(Boolean),
        lockKinds: [LockKind.PLAYER_INPUT, LockKind.WORLD_INTERACTION, LockKind.CAMERA, LockKind.TRANSITION],
        validate: async () => {
          const doc = this.#documents.require(a.documentId);
          return doc.stampable && doc.stampType == null && this.#player.state === PlayerState.STAMP;
        },
        prepare: async () => a.hooks?.preImpact?.(),
        play: async () => {
          await a.hooks?.downstroke?.(() => {
            this.#markers.fireOnce(a.sequenceId, 'STAMP_IMPACT', () => {
              this.#documents.recordStamp(a.documentId, a.stampType);
              a.hooks?.impact?.(a.stampType);
              this.#events?.emit('STAMP_IMPACT', { sequenceId: a.sequenceId, documentId: a.documentId, stampType: a.stampType });
            });
          });
          invariant(this.#markers.has(a.sequenceId, 'STAMP_IMPACT'), 'STAMP_IMPACT marker never fired');
        },
        verify: async () => this.#documents.require(a.documentId).stampType === a.stampType && (await a.hooks?.verify?.() ?? true),
        commit: async () => {
          await a.chapterCommit?.(a.stampType);
          this.#events?.emit('stamp:committed', { sequenceId: a.sequenceId, stampType: a.stampType });
        },
        rollback: async () => { this.#documents.replaceState(a.documentId, documentBeforeImpact); await a.hooks?.rollback?.(); },
        cleanup: async () => { await a.hooks?.liftAndReturn?.(); },
      });
      this.#player.setState(a.hooks?.nextPlayerState ?? PlayerState.DIALOGUE, `${a.sequenceId}:done`);
      this.#active = null; return true;
    } catch (error) {
      this.#player.setState(PlayerState.INSPECT, `${a.sequenceId}:failed`);
      this.#active = null; throw error;
    }
  }
  cancel() {
    if (!this.#active || this.#active.impactStarted) return false;
    const a = this.#active; this.#active = null; a.hooks?.cancel?.(); this.#player.setState(PlayerState.INSPECT, `${a.sequenceId}:cancel`); return true;
  }
}
