export const PlayerState = Object.freeze({
  FREE: 'FREE',
  FOCUS: 'FOCUS',
  DIALOGUE: 'DIALOGUE',
  INSPECT: 'INSPECT',
  CARRY: 'CARRY',
  STAMP: 'STAMP',
  CINEMATIC: 'CINEMATIC',
  LOCKED: 'LOCKED',
  TRANSITION: 'TRANSITION',
});

export const InputAction = Object.freeze({
  MOVE_FORWARD: 'MOVE_FORWARD', MOVE_BACK: 'MOVE_BACK', MOVE_LEFT: 'MOVE_LEFT', MOVE_RIGHT: 'MOVE_RIGHT',
  LOOK_DELTA: 'LOOK_DELTA', INTERACT: 'INTERACT', CONFIRM: 'CONFIRM', CANCEL: 'CANCEL',
  ADVANCE_DIALOGUE: 'ADVANCE_DIALOGUE', INSPECT_ROTATE: 'INSPECT_ROTATE', INSPECT_FLIP: 'INSPECT_FLIP',
  CARRY_DROP: 'CARRY_DROP', PAUSE: 'PAUSE', FULLSCREEN: 'FULLSCREEN',
});

export const LockKind = Object.freeze({
  PLAYER_INPUT: 'PLAYER_INPUT', WORLD_INTERACTION: 'WORLD_INTERACTION', CAMERA: 'CAMERA', NPC: 'NPC',
  OBJECT: 'OBJECT', DOOR: 'DOOR', DIALOGUE_ADVANCE: 'DIALOGUE_ADVANCE', TRANSITION: 'TRANSITION',
});

export const OwnerPriority = Object.freeze({
  IDLE: 10, TASK: 20, INTERACTION: 30, DIALOGUE: 40, INSPECT: 50, STAMP: 50,
  STORY_SEQUENCE: 60, CHAPTER_CINEMATIC: 70, TRANSITION: 80,
});

export const SpoilerLevel = Object.freeze({ LEVEL_0: 0, LEVEL_1: 1, LEVEL_2: 2, LEVEL_3: 3 });
export const StampType = Object.freeze({ REJECTED: 'REJECTED', APPROVED: 'APPROVED' });
export const SequenceStatus = Object.freeze({ NOT_STARTED: 'NOT_STARTED', ACTIVE: 'ACTIVE', COMMITTED: 'COMMITTED', FAILED: 'FAILED' });

export const InteractionPriority = Object.freeze({
  DECORATIVE: 10, ENVIRONMENT: 20, NPC: 30, CHAPTER_OBJECT: 40, CURRENT_TARGET: 50, ACTIVE_REQUIRED: 60,
});

export const DefaultSave = Object.freeze({
  saveVersion: 1,
  chapterId: 'CH01',
  checkpointId: 'CH01_START',
  progress: { facilityPercent: 0, approvedChapters: [] },
  story: { flags: {} },
  documents: {},
  objects: {},
  archive: { unlocked: false, index: 0 },
});
