import * as THREE from 'three';
import { PlayerState } from '../constants.js';

export class PlayerController {
  state = PlayerState.LOCKED;
  root = new THREE.Object3D();
  velocity = new THREE.Vector3();
  moveSpeed = 1.75;
  eyeHeight = 1.65;
  #events; #router;
  constructor({ events, inputRouter }) { this.#events = events; this.#router = inputRouter; this.root.name = 'PLAYER_ROOT'; }
  setState(next, reason = '') {
    if (this.state === next) return;
    const previous = this.state;
    this.velocity.set(0, 0, 0);
    this.#router?.resetTransient();
    this.state = next;
    this.#events?.emit('player:state', { previous, next, reason });
  }
  update(dt, movement, cameraYaw, collision) {
    if (![PlayerState.FREE, PlayerState.CARRY].includes(this.state)) return;
    const local = new THREE.Vector3(movement.right, 0, -movement.forward);
    if (local.lengthSq() > 1) local.normalize();
    local.applyAxisAngle(new THREE.Vector3(0, 1, 0), cameraYaw).multiplyScalar(this.moveSpeed * dt);
    const desired = this.root.position.clone().add(local);
    this.root.position.copy(collision?.resolvePlayerPosition?.(this.root.position, desired) ?? desired);
  }
}
