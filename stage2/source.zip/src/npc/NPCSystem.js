import * as THREE from 'three';
import { invariant } from '../core/assert.js';

export class NPCSystem {
  #npcs = new Map(); #anchors; #tweens; #ownership;
  constructor({ anchors, tweens, ownership }) { this.#anchors = anchors; this.#tweens = tweens; this.#ownership = ownership; }
  register(id, object3D, data = {}) {
    invariant(!this.#npcs.has(id), `Duplicate NPC: ${id}`);
    this.#npcs.set(id, { id, object3D, publicName: data.publicName ?? id, identityLevel: data.identityLevel ?? 3,
      state: { movement: 'IDLE', task: 'WAIT', dialogue: 'NONE', interaction: 'NONE', emotion: 'NEUTRAL', gaze: 'AMBIENT', ...data.state } });
  }
  get(id) { return this.#npcs.get(id) ?? null; }
  setFacet(id, facet, value) { const npc = this.get(id); invariant(npc, `Missing NPC: ${id}`); npc.state[facet] = value; }
  async moveToAnchor(id, anchorId, { duration = 900, owner = 'TASK', priority = 20, signal } = {}) {
    const npc = this.get(id); const anchor = this.#anchors.require(anchorId);
    if (!this.#ownership.claim(id, owner, priority)) return false;
    try {
      npc.state.movement = 'MOVING';
      const target = anchor.getWorldPosition(new THREE.Vector3());
      await this.#tweens.to(npc.object3D.position, { x: target.x, y: target.y, z: target.z }, { duration, signal });
      npc.state.movement = 'AT_ANCHOR'; return true;
    } finally { this.#ownership.release(id, owner); }
  }
}
