import * as THREE from 'three';

export class NPCGestureSystem {
  #entries = new Map();
  register(npcId, root, clips = []) {
    const mixer = new THREE.AnimationMixer(root);
    const byName = new Map(clips.map(clip => [clip.name, clip]));
    this.#entries.set(npcId, { mixer, byName, current: null });
    return mixer;
  }
  play(npcId, clipName, { loop = THREE.LoopOnce, repetitions = 1, clamp = true, fadeIn = 0.08, timeScale = 1 } = {}) {
    const entry = this.#entries.get(npcId); if (!entry) return null;
    const clip = entry.byName.get(clipName); if (!clip) return null;
    const action = entry.mixer.clipAction(clip);
    if (entry.current && entry.current !== action) entry.current.fadeOut(fadeIn);
    action.reset().setLoop(loop, repetitions).setEffectiveTimeScale(timeScale); action.clampWhenFinished = clamp;
    if (fadeIn > 0) action.fadeIn(fadeIn); action.play(); entry.current = action; return action;
  }
  stop(npcId, fadeOut = 0.08) { const e = this.#entries.get(npcId); if (!e?.current) return; e.current.fadeOut(fadeOut); e.current = null; }
  update(delta) { for (const e of this.#entries.values()) e.mixer.update(delta); }
  clear() { for (const e of this.#entries.values()) e.mixer.stopAllAction(); this.#entries.clear(); }
}
