import * as THREE from 'three';

export class FacilitySystem {
  root = new THREE.Group();
  zones = new Map();
  #anchors; #collision;
  constructor({ anchors, collision }) { this.#anchors = anchors; this.#collision = collision; this.root.name = 'FACILITY_ROOT'; }
  addZone(id, object3D, { colliders = [], anchors = [] } = {}) {
    object3D.name ||= id; this.root.add(object3D); this.zones.set(id, object3D);
    for (const c of colliders) this.#collision.addBox(c.object3D ?? c, c.padding ?? 0);
    for (const a of anchors) this.#anchors.register(a.id, a.object3D, a.meta);
    return object3D;
  }
  setZoneVisible(id, visible) { const zone = this.zones.get(id); if (zone) zone.visible = visible; }
  clear() { this.root.clear(); this.zones.clear(); this.#collision.clear(); this.#anchors.clear(); }
}
