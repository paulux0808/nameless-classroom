import { invariant } from '../core/assert.js';

const FIXED_PROGRESS = Object.freeze([0, 8, 19, 31, 44, 57, 69, 82, 100]);

export class FacilityProgress {
  #game;
  constructor(game) { this.#game = game; }
  percentForApprovedCount(count) { return FIXED_PROGRESS[Math.max(0, Math.min(8, count))]; }
  async commitApprovedChapter(chapterNumber) {
    const prior = this.#game.store.state.progress.approvedChapters ?? [];
    invariant(Number.isInteger(chapterNumber) && chapterNumber >= 1 && chapterNumber <= 8, `Invalid approval chapter: ${chapterNumber}`);
    invariant(chapterNumber === prior.length + 1, `Approval must be sequential: expected ${prior.length + 1}, got ${chapterNumber}`);
    const current = new Set(prior);
    current.add(chapterNumber);
    const approved = [...current].sort((a, b) => a - b);
    const percent = this.percentForApprovedCount(approved.length);
    await this.#game.commit(`facility:approved:${chapterNumber}`, draft => {
      draft.progress.approvedChapters = approved;
      draft.progress.facilityPercent = percent;
    }, { checkpointId: `CH${String(chapterNumber).padStart(2, '0')}_COMPLETE`, critical: true });
    this.#game.events.emit('facility:progress', { approved, percent });
    return percent;
  }
}
