export class ReservationManager {
  #items = new Map();
  reserve(resourceId, owner) {
    const current = this.#items.get(resourceId);
    if (current && current !== owner) return false;
    this.#items.set(resourceId, owner); return true;
  }
  reserveMany(ids, owner) {
    const done = [];
    for (const id of ids) {
      if (!this.reserve(id, owner)) { done.forEach(x => this.release(x, owner)); return false; }
      done.push(id);
    }
    return true;
  }
  release(resourceId, owner) { if (this.#items.get(resourceId) === owner) this.#items.delete(resourceId); }
  releaseMany(ids, owner) { ids.forEach(id => this.release(id, owner)); }
  ownerOf(id) { return this.#items.get(id) ?? null; }
  reset() { this.#items.clear(); }
}
