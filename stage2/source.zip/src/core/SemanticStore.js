import { deepClone, invariant } from './assert.js';

export class SemanticStore {
  #state; #events;
  constructor(initialState, events) { this.#state = deepClone(initialState); this.#events = events; }
  get state() { return this.#state; }
  snapshot() { return deepClone(this.#state); }
  read(path) {
    return path.split('.').reduce((o, k) => o?.[k], this.#state);
  }
  transaction(label, mutator, validate = null) {
    const before = this.snapshot();
    const next = this.snapshot();
    mutator(next);
    if (validate) invariant(validate(next, before) !== false, `Semantic transaction rejected: ${label}`);
    this.#state = next;
    this.#events?.emit('semantic:commit', { label, before, after: this.snapshot() });
    return this.#state;
  }
  replace(next, label = 'replace') {
    const before = this.snapshot();
    this.#state = deepClone(next);
    this.#events?.emit('semantic:commit', { label, before, after: this.snapshot() });
  }
}
