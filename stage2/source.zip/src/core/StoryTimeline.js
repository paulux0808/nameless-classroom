export class StoryTimeline {
  #id; #markers; #ledger; #elapsedMs = 0; #cursor = 0; #running = false; #complete = false;
  constructor({ id, markers = [], ledger }) {
    this.#id = id; this.#ledger = ledger;
    this.#markers = [...markers].sort((a, b) => a.atMs - b.atMs);
  }
  get elapsedMs() { return this.#elapsedMs; }
  get complete() { return this.#complete; }
  start({ elapsedMs = 0 } = {}) { this.#elapsedMs = Math.max(0, elapsedMs); this.#running = true; this.#complete = false; return this; }
  pause() { this.#running = false; }
  resume() { if (!this.#complete) this.#running = true; }
  reset() { this.#elapsedMs = 0; this.#cursor = 0; this.#running = false; this.#complete = false; }
  update(deltaSeconds) {
    if (!this.#running || this.#complete) return null;
    this.#elapsedMs += Math.max(0, deltaSeconds) * 1000;
    const marker = this.#markers[this.#cursor];
    if (!marker) { this.#complete = true; this.#running = false; return null; }
    if (this.#elapsedMs < marker.atMs) return null;
    this.#cursor += 1;
    this.#ledger.fireOnce(this.#id, marker.id, () => marker.run?.({ elapsedMs: this.#elapsedMs, marker }));
    if (this.#cursor >= this.#markers.length) { this.#complete = true; this.#running = false; }
    return marker.id;
  }
}
