export class RuntimeClock {
  #last = performance.now(); #elapsed = 0;
  tick(now = performance.now()) {
    const raw = Math.max(0, (now - this.#last) / 1000);
    this.#last = now;
    const delta = Math.min(raw, 0.1);
    this.#elapsed += raw;
    return { now, rawDelta: raw, delta, elapsed: this.#elapsed, hitch: raw > 0.1 };
  }
  reset(now = performance.now()) { this.#last = now; }
}
