import { SequenceStatus } from '../constants.js';

export class SequenceRunner {
  #locks; #reservations; #ownership; #events; #status = new Map();
  constructor({ locks, reservations, ownership, events }) { this.#locks = locks; this.#reservations = reservations; this.#ownership = ownership; this.#events = events; }
  status(id) { return this.#status.get(id) ?? SequenceStatus.NOT_STARTED; }
  async run(job, signal) {
    if (this.status(job.id) === SequenceStatus.COMMITTED && job.idempotent !== false) return { committed: true, skipped: true };
    if (this.status(job.id) === SequenceStatus.ACTIVE) throw new Error(`Sequence already active: ${job.id}`);
    this.#status.set(job.id, SequenceStatus.ACTIVE);
    const owner = job.owner ?? job.id;
    const reserved = job.reserveIds ?? [];
    const targets = job.targetIds ?? [];
    let lockTokens = [];
    try {
      if (job.validate && (await job.validate({ signal })) === false) throw new Error(`VALIDATE failed: ${job.id}`);
      if (!this.#reservations.reserveMany(reserved, owner)) throw new Error(`RESERVE failed: ${job.id}`);
      for (const target of targets) if (!this.#ownership.claim(target, owner, job.priority, { takeover: job.takeover })) throw new Error(`OWNERSHIP failed: ${job.id}:${target}`);
      lockTokens = this.#locks.acquireMany(job.lockKinds ?? [], owner);
      if (!lockTokens) throw new Error(`LOCK failed: ${job.id}`);
      await job.prepare?.({ signal });
      await job.play?.({ signal });
      if (job.verify && (await job.verify({ signal })) === false) throw new Error(`VERIFY failed: ${job.id}`);
      await job.commit?.({ signal });
      this.#status.set(job.id, SequenceStatus.COMMITTED);
      this.#events?.emit('sequence:committed', { id: job.id });
      return { committed: true };
    } catch (error) {
      this.#status.set(job.id, SequenceStatus.FAILED);
      try { await job.rollback?.({ error, signal }); } catch { /* original error wins */ }
      this.#events?.emit('sequence:failed', { id: job.id, error });
      throw error;
    } finally {
      try { await job.cleanup?.(); } finally {
        this.#locks.releaseAll(lockTokens);
        this.#reservations.releaseMany(reserved, owner);
        this.#ownership.releaseMany(targets, owner);
      }
    }
  }
}
