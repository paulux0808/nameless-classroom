import { invariant } from './assert.js';

export class LockManager {
  #locks = new Map();
  acquire(kind, owner) {
    invariant(kind && owner, 'Lock requires kind and owner');
    const current = this.#locks.get(kind);
    if (current && current.owner !== owner) return null;
    const token = Symbol(`${kind}:${owner}`);
    if (current) current.tokens.add(token);
    else this.#locks.set(kind, { owner, tokens: new Set([token]) });
    return { kind, owner, token };
  }
  acquireMany(kinds, owner) {
    const out = [];
    for (const kind of kinds) {
      const token = this.acquire(kind, owner);
      if (!token) { for (const t of out.reverse()) this.release(t); return null; }
      out.push(token);
    }
    return out;
  }
  release(token) {
    if (!token) return;
    const current = this.#locks.get(token.kind);
    if (!current || current.owner !== token.owner || !current.tokens.has(token.token)) return;
    current.tokens.delete(token.token);
    if (!current.tokens.size) this.#locks.delete(token.kind);
  }
  releaseAll(tokens = []) { for (const t of [...tokens].reverse()) this.release(t); }
  isLocked(kind) { return this.#locks.has(kind); }
  ownerOf(kind) { return this.#locks.get(kind)?.owner ?? null; }
  reset() { this.#locks.clear(); }
}
