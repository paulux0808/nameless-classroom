import { Group, Tween, Easing } from '@tweenjs/tween.js';

export class TweenService {
  #group = new Group(); #timeMs = 0;
  updateDelta(deltaMs) { this.#timeMs += Math.max(0, deltaMs); this.#group.update(this.#timeMs); }
  to(target, values, { duration = 400, easing = Easing.Cubic.InOut, delay = 0, signal, onUpdate } = {}) {
    return new Promise((resolve, reject) => {
      if (signal?.aborted) return reject(signal.reason ?? new DOMException('Aborted', 'AbortError'));
      const tween = new Tween(target); this.#group.add(tween);
      tween.to(values, duration).easing(easing).delay(delay)
        .onUpdate(() => onUpdate?.(target))
        .onComplete(() => { cleanup(); resolve(target); })
        .onStop(() => { cleanup(); reject(new DOMException('Aborted', 'AbortError')); });
      const abort = () => tween.stop();
      const cleanup = () => signal?.removeEventListener('abort', abort);
      signal?.addEventListener('abort', abort, { once: true });
      tween.start(this.#timeMs);
    });
  }
  wait(ms, signal) {
    const holder = { value: 0 };
    return this.to(holder, { value: 1 }, { duration: ms, easing: k => k, signal });
  }
  sequence(steps, signal) { return steps.reduce((p, step) => p.then(() => step(signal)), Promise.resolve()); }
  parallel(steps, signal) { return Promise.all(steps.map(step => step(signal))); }
}
