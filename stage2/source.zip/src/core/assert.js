export function invariant(condition, message = 'Invariant failed') {
  if (!condition) throw new Error(message);
}
export function clamp(value, min, max) { return Math.min(max, Math.max(min, value)); }
export function deepClone(value) { return structuredClone(value); }
