export class MarkerLedger {
  #fired = new Set();
  fireOnce(sequenceId, marker, fn) {
    const key = `${sequenceId}::${marker}`;
    if (this.#fired.has(key)) return false;
    this.#fired.add(key); fn?.(); return true;
  }
  has(sequenceId, marker) { return this.#fired.has(`${sequenceId}::${marker}`); }
  clearSequence(sequenceId) { for (const k of [...this.#fired]) if (k.startsWith(`${sequenceId}::`)) this.#fired.delete(k); }
  reset() { this.#fired.clear(); }
}
