export class EventBus {
  #listeners = new Map();
  on(type, fn) {
    const set = this.#listeners.get(type) ?? new Set();
    set.add(fn); this.#listeners.set(type, set);
    return () => this.off(type, fn);
  }
  once(type, fn) { const off = this.on(type, (...args) => { off(); fn(...args); }); return off; }
  off(type, fn) { this.#listeners.get(type)?.delete(fn); }
  emit(type, payload) { for (const fn of [...(this.#listeners.get(type) ?? [])]) fn(payload); }
  clear() { this.#listeners.clear(); }
}
