import { OwnerPriority } from '../constants.js';

export class OwnershipManager {
  #targets = new Map();
  claim(targetId, owner, priority = OwnerPriority.INTERACTION, { takeover = false } = {}) {
    const current = this.#targets.get(targetId);
    if (!current) { this.#targets.set(targetId, { owner, priority, previous: null }); return true; }
    if (current.owner === owner) return true;
    if (!takeover || priority <= current.priority) return false;
    this.#targets.set(targetId, { owner, priority, previous: current });
    return true;
  }
  release(targetId, owner) {
    const current = this.#targets.get(targetId);
    if (current?.owner !== owner) return;
    if (current.previous) this.#targets.set(targetId, current.previous);
    else this.#targets.delete(targetId);
  }
  releaseMany(ids, owner) { ids.forEach(id => this.release(id, owner)); }
  ownerOf(id) { return this.#targets.get(id)?.owner ?? null; }
  priorityOf(id) { return this.#targets.get(id)?.priority ?? null; }
  reset() { this.#targets.clear(); }
}
