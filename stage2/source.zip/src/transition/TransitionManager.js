import { LockKind, PlayerState } from '../constants.js';

export class TransitionManager {
  committed = false;
  #player; #locks; #save; #fade; #navigate;
  constructor({ player, locks, saveManager, fade = async () => {}, navigate = url => location.assign(url) }) {
    this.#player = player; this.#locks = locks; this.#save = saveManager; this.#fade = fade; this.#navigate = navigate;
  }
  async go({ url, saveData, nextChapterId = null, nextCheckpointId = null }) {
    if (this.committed) return false;
    this.committed = true;
    const tokens = this.#locks.acquireMany([LockKind.PLAYER_INPUT, LockKind.WORLD_INTERACTION, LockKind.CAMERA, LockKind.TRANSITION], 'TRANSITION');
    if (!tokens) { this.committed = false; return false; }
    this.#player.setState(PlayerState.TRANSITION, 'chapter transition');
    try {
      const nextSave = structuredClone(saveData);
      if (nextChapterId) nextSave.chapterId = nextChapterId;
      if (nextCheckpointId) nextSave.checkpointId = nextCheckpointId;
      await this.#fade('out');
      await this.#save.save(nextSave, { critical: true });
      this.#navigate(url);
      return true;
    } catch (error) {
      this.#locks.releaseAll(tokens);
      this.committed = false;
      this.#player.setState(PlayerState.FREE, 'transition failed');
      throw error;
    }
  }
}
