import * as THREE from 'three';
import { acceleratedRaycast, computeBoundsTree, disposeBoundsTree } from 'three-mesh-bvh';
import { InteractionPriority, PlayerState } from '../constants.js';

THREE.BufferGeometry.prototype.computeBoundsTree ??= computeBoundsTree;
THREE.BufferGeometry.prototype.disposeBoundsTree ??= disposeBoundsTree;
THREE.Mesh.prototype.raycast = acceleratedRaycast;

export class InteractionSystem {
  #targets = new Map(); #camera; #raycaster = new THREE.Raycaster(); #center = new THREE.Vector2(0, 0); #getContext; #spoiler;
  constructor({ camera, getContext, spoilerGuard }) { this.#camera = camera; this.#getContext = getContext; this.#spoiler = spoilerGuard; this.#raycaster.firstHitOnly = true; }
  register({ id, object3D, proxy = object3D, maxDistance = 2.25, priority = InteractionPriority.ENVIRONMENT, states = [PlayerState.FREE], enabled = () => true, label = '', action }) {
    proxy.userData.interactionId = id;
    proxy.traverse?.(node => {
      if (node.isMesh && node.geometry && !node.geometry.boundsTree) node.geometry.computeBoundsTree?.();
    });
    this.#targets.set(id, { id, object3D, proxy, maxDistance, priority, states: new Set(states), enabled, label, action });
    return () => this.#targets.delete(id);
  }
  pickCenter() {
    const context = this.#getContext();
    const candidates = [...this.#targets.values()].filter(t => t.states.has(context.playerState) && t.enabled(context));
    if (!candidates.length) return null;
    this.#raycaster.setFromCamera(this.#center, this.#camera);
    const intersections = this.#raycaster.intersectObjects(candidates.map(x => x.proxy), true);
    const resolved = [];
    for (const hit of intersections) {
      let node = hit.object;
      while (node && !node.userData.interactionId) node = node.parent;
      const t = node ? this.#targets.get(node.userData.interactionId) : null;
      if (!t || hit.distance > t.maxDistance) continue;
      resolved.push({ target: t, hit });
    }
    resolved.sort((a, b) => b.target.priority - a.target.priority || a.hit.distance - b.hit.distance);
    return resolved[0] ?? null;
  }
  currentLabel() { const pick = this.pickCenter(); return pick ? this.#spoiler.safeText(pick.target.label) : ''; }
  interact() { const pick = this.pickCenter(); if (!pick) return false; pick.target.action?.({ hit: pick.hit, context: this.#getContext() }); return true; }
}
