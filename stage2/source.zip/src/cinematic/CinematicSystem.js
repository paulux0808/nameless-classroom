import { LockKind, OwnerPriority, PlayerState } from '../constants.js';

export class CinematicSystem {
  #player; #sequences; #events; activeId = null;
  constructor({ player, sequences, events }) { this.#player = player; this.#sequences = sequences; this.#events = events; }
  async run({ id, soft = false, targetIds = [], reserveIds = [], validate, prepare, beats = [], verify, commit, rollback, nextState = PlayerState.FREE }) {
    if (this.activeId) throw new Error(`Cinematic already active: ${this.activeId}`);
    this.activeId = id;
    this.#player.setState(PlayerState.CINEMATIC, id);
    this.#events?.emit('cinematic:start', { id, soft });
    try {
      await this.#sequences.run({
        id,
        owner: id,
        priority: OwnerPriority.CHAPTER_CINEMATIC,
        targetIds,
        reserveIds,
        lockKinds: soft
          ? [LockKind.WORLD_INTERACTION, LockKind.TRANSITION]
          : [LockKind.PLAYER_INPUT, LockKind.WORLD_INTERACTION, LockKind.CAMERA, LockKind.TRANSITION],
        validate,
        prepare,
        play: async ({ signal }) => { for (const beat of beats) await beat({ signal }); },
        verify,
        commit,
        rollback,
      });
      this.#player.setState(nextState, `${id}:complete`);
      this.#events?.emit('cinematic:end', { id, committed: true });
    } catch (error) {
      this.#player.setState(PlayerState.FREE, `${id}:failed`);
      this.#events?.emit('cinematic:end', { id, committed: false, error });
      throw error;
    } finally { this.activeId = null; }
  }
}
