import { InputAction } from '../constants.js';

export class MobileControls {
  movePointerId = null; lookPointerId = null; actionPointerId = null;
  move = { x: 0, y: 0 }; look = { x: 0, y: 0 };
  #router; #root; #lastLook = new Map(); #enabled = false;
  constructor({ router, root = document.body }) { this.#router = router; this.#root = root; }
  enable() {
    if (this.#enabled) return; this.#enabled = true;
    this.#root.addEventListener('pointerdown', this.#down, { passive: false });
    this.#root.addEventListener('pointermove', this.#move, { passive: false });
    this.#root.addEventListener('pointerup', this.#up, { passive: false });
    this.#root.addEventListener('pointercancel', this.#up, { passive: false });
    addEventListener('blur', this.reset);
    document.addEventListener('visibilitychange', this.#visibility);
  }
  disable() {
    if (!this.#enabled) return; this.#enabled = false;
    this.#root.removeEventListener('pointerdown', this.#down);
    this.#root.removeEventListener('pointermove', this.#move);
    this.#root.removeEventListener('pointerup', this.#up);
    this.#root.removeEventListener('pointercancel', this.#up);
    removeEventListener('blur', this.reset);
    document.removeEventListener('visibilitychange', this.#visibility);
    this.reset();
  }
  sampleMovement() { return { forward: -this.move.y, right: this.move.x }; }
  consumeLookDelta() { const out = { ...this.look }; this.look.x = this.look.y = 0; return out; }
  reset = () => { this.movePointerId = this.lookPointerId = this.actionPointerId = null; this.move.x = this.move.y = this.look.x = this.look.y = 0; this.#lastLook.clear(); this.#router.resetTransient(); };
  #zone(e) {
    const x = e.clientX / innerWidth, y = e.clientY / innerHeight;
    if (e.target?.closest?.('[data-n2-action]')) return 'ACTION';
    if (e.target?.closest?.('button,input,textarea,select,[data-n2-ui-interactive]')) return 'UI';
    if (x < 0.45 && y > 0.35) return 'MOVE';
    return 'LOOK';
  }
  #down = e => {
    const zone = this.#zone(e);
    if (zone === 'UI') return;
    e.preventDefault();
    if (zone === 'MOVE' && this.movePointerId == null) this.movePointerId = e.pointerId;
    else if (zone === 'LOOK' && this.lookPointerId == null) { this.lookPointerId = e.pointerId; this.#lastLook.set(e.pointerId, { x: e.clientX, y: e.clientY }); }
    else if (zone === 'ACTION' && this.actionPointerId == null) { this.actionPointerId = e.pointerId; this.#router.dispatchPrimary({ originalEvent: e }); }
  };
  #move = e => {
    if (e.pointerId === this.movePointerId) {
      const x = (e.clientX / innerWidth - 0.22) / 0.2, y = (e.clientY / innerHeight - 0.72) / 0.25;
      const m = Math.hypot(x, y) || 1;
      this.move.x = Math.max(-1, Math.min(1, x / Math.max(1, m)));
      this.move.y = Math.max(-1, Math.min(1, y / Math.max(1, m)));
    } else if (e.pointerId === this.lookPointerId) {
      const prev = this.#lastLook.get(e.pointerId) ?? { x: e.clientX, y: e.clientY };
      this.look.x += e.clientX - prev.x; this.look.y += e.clientY - prev.y;
      this.#lastLook.set(e.pointerId, { x: e.clientX, y: e.clientY });
    }
  };
  #up = e => {
    if (e.pointerId === this.movePointerId) { this.movePointerId = null; this.move.x = this.move.y = 0; }
    if (e.pointerId === this.lookPointerId) { this.lookPointerId = null; this.#lastLook.delete(e.pointerId); }
    if (e.pointerId === this.actionPointerId) {
      this.actionPointerId = null;
      this.#router.release(InputAction.INTERACT);
      this.#router.release(InputAction.CONFIRM);
      this.#router.release(InputAction.ADVANCE_DIALOGUE);
    }
  };
  #visibility = () => { if (document.hidden) this.reset(); };
}
