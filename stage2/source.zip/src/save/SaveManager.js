import { get, set, del } from 'idb-keyval';
import { sha256 } from '@noble/hashes/sha2.js';

async function sha256Hex(text) {
  const digest = sha256(new TextEncoder().encode(text));
  return [...digest].map(x => x.toString(16).padStart(2, '0')).join('');
}

export class SaveManager {
  #key; #backupKey; #tempKey; #version; #validate; #migrate; #timer = null; #events; #queuedData = null; #waiters = [];
  #memory = new Map(); #persistentAvailable = true; #warnedPersistence = false;
  constructor({ key = 'nameless2.story', saveVersion = 1, validate, migrate, events }) {
    this.#key = key; this.#backupKey = `${key}.backup`; this.#tempKey = `${key}.temp`; this.#version = saveVersion; this.#validate = validate; this.#migrate = migrate; this.#events = events;
  }
  get persistentAvailable() { return this.#persistentAvailable; }
  async #dbGet(key) {
    if (!this.#persistentAvailable) return this.#memory.get(key) ?? null;
    try { return await get(key); }
    catch (error) { this.#downgradePersistence(error); return this.#memory.get(key) ?? null; }
  }
  async #dbSet(key, value) {
    this.#memory.set(key, structuredClone(value));
    if (!this.#persistentAvailable) return;
    try { await set(key, value); }
    catch (error) { this.#downgradePersistence(error); }
  }
  async #dbDel(key) {
    this.#memory.delete(key);
    if (!this.#persistentAvailable) return;
    try { await del(key); }
    catch (error) { this.#downgradePersistence(error); }
  }
  #downgradePersistence(error) {
    this.#persistentAvailable = false;
    if (!this.#warnedPersistence) {
      this.#warnedPersistence = true;
      this.#events?.emit('save:persistence-unavailable', { error });
    }
  }
  async #wrap(data) {
    const normalized = { ...structuredClone(data), saveVersion: this.#version };
    const payload = JSON.stringify(normalized);
    return { saveVersion: this.#version, payload, checksum: await sha256Hex(payload), writtenAt: Date.now() };
  }
  async #unwrap(record) {
    if (!record?.payload || !record?.checksum) throw new Error('Invalid save record');
    if (await sha256Hex(record.payload) !== record.checksum) throw new Error('Save checksum mismatch');
    let data = JSON.parse(record.payload);
    if (data.saveVersion !== this.#version) data = await this.#migrate?.(data, this.#version) ?? data;
    if (data.saveVersion !== this.#version) throw new Error(`Unsupported save version: ${data.saveVersion}`);
    if (this.#validate && (await this.#validate(data)) === false) throw new Error('Save semantic validation failed');
    return data;
  }
  async load() {
    const main = await this.#dbGet(this.#key);
    if (main) { try { return await this.#unwrap(main); } catch (error) { this.#events?.emit('save:corrupt', { source: 'main', error }); } }
    const backup = await this.#dbGet(this.#backupKey);
    if (backup) { try { return await this.#unwrap(backup); } catch (error) { this.#events?.emit('save:corrupt', { source: 'backup', error }); } }
    return null;
  }
  async save(data, { critical = false } = {}) {
    if (!critical) return this.debounced(data);
    return this.#write(data);
  }
  debounced(data, ms = 250) {
    this.#queuedData = structuredClone(data);
    clearTimeout(this.#timer);
    return new Promise((resolve, reject) => {
      this.#waiters.push({ resolve, reject });
      this.#timer = setTimeout(async () => {
        const queued = this.#queuedData; this.#queuedData = null; const waiters = this.#waiters.splice(0);
        try { const result = await this.#write(queued); waiters.forEach(w => w.resolve(result)); }
        catch (error) { waiters.forEach(w => w.reject(error)); }
      }, ms);
    });
  }
  async flush() {
    if (!this.#queuedData) return true;
    clearTimeout(this.#timer);
    const queued = this.#queuedData; this.#queuedData = null; const waiters = this.#waiters.splice(0);
    try { const result = await this.#write(queued); waiters.forEach(w => w.resolve(result)); return result; }
    catch (error) { waiters.forEach(w => w.reject(error)); throw error; }
  }
  async #write(data) {
    const wrapped = await this.#wrap(data);
    const previous = await this.#dbGet(this.#key);
    await this.#dbSet(this.#tempKey, wrapped);
    if (previous) await this.#dbSet(this.#backupKey, previous);
    await this.#dbSet(this.#key, wrapped);
    await this.#dbDel(this.#tempKey);
    this.#events?.emit('save:written', { checkpointId: data.checkpointId, chapterId: data.chapterId, persistent: this.#persistentAvailable });
    return true;
  }
  async reset() { await Promise.all([this.#dbDel(this.#key), this.#dbDel(this.#backupKey), this.#dbDel(this.#tempKey)]); }
}
