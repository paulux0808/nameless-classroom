import { DefaultSave, SpoilerLevel } from '../constants.js';

function defaultChapterUrl(chapterId) {
  const n = /^CH(\d{2})$/.exec(chapterId)?.[1];
  return n ? `chapter${n}.html` : null;
}

export class ChapterRuntime {
  #game; #definition;
  constructor(game, definition) { this.#game = game; this.#definition = definition; }
  async start() {
    const save = await this.#game.save.load();
    if (save && save.chapterId !== this.#definition.id && !this.#game.dev) {
      const resolveUrl = this.#definition.resolveChapterUrl ?? defaultChapterUrl;
      const url = resolveUrl(save.chapterId);
      if (!url) throw new Error(`Cannot resolve saved chapter URL: ${save.chapterId}`);
      location.replace(url);
      return { redirected: true, chapterId: save.chapterId };
    }
    const resolved = save && save.chapterId === this.#definition.id ? save : structuredClone(DefaultSave);
    resolved.chapterId = this.#definition.id;
    resolved.checkpointId = save && this.#game.dev && save.chapterId !== this.#definition.id
      ? `${this.#definition.id}_START`
      : resolved.checkpointId;
    this.#game.store.replace(resolved, 'chapter:load');
    const level = this.#definition.spoilerLevel ?? SpoilerLevel.LEVEL_0;
    this.#game.spoiler.setLevel(level);
    await this.#definition.loadAssets?.(this.#game);
    await this.#definition.buildScene?.(this.#game);
    await this.#definition.registerContent?.(this.#game);
    await this.#definition.reconstruct?.(this.#game, this.#game.store.snapshot());
    await this.#definition.onReady?.(this.#game);
    return { redirected: false, chapterId: this.#definition.id };
  }
  update(frame) { this.#definition.update?.(this.#game, frame); }
  async dispose() { await this.#definition.dispose?.(this.#game); }
}

