export const VisualConfig = Object.freeze({
  renderer: { toneMapping: 'ACES_FILMIC', exposure: 1.0, physicallyCorrectScale: true },
  style: { historicalRealism: true, avoidGlobalSepia: true, avoidHeavyFilmGrain: true, restrainedBloom: true },
  priorityDetail: ['STAMP', 'PHONE', 'PHOTO', 'MEDAL', 'POSTCARD', 'DOCUMENT', 'NPC_FACE', 'NPC_HANDS'],
});
