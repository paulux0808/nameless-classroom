export class UISystem {
  #root; #reticle; #label; #subtitle; #speaker; #action;
  constructor(root = document.body) {
    this.#root = root;
    this.#root.insertAdjacentHTML('beforeend', `
      <div id="n2-ui" aria-live="polite">
        <div id="n2-reticle" aria-hidden="true"></div>
        <div id="n2-interaction-label"></div>
        <div id="n2-dialogue"><div id="n2-speaker"></div><div id="n2-subtitle"></div></div>
        <button id="n2-action" data-n2-action type="button">ACTION</button>
      </div>`);
    this.#reticle = document.querySelector('#n2-reticle'); this.#label = document.querySelector('#n2-interaction-label');
    this.#subtitle = document.querySelector('#n2-subtitle'); this.#speaker = document.querySelector('#n2-speaker'); this.#action = document.querySelector('#n2-action');
  }
  setInteractionLabel(text = '') { this.#label.textContent = text; }
  setDialogue({ speaker = '', text = '' } = {}) { this.#speaker.textContent = speaker; this.#subtitle.textContent = text; }
  clearDialogue() { this.setDialogue(); }
  setAction(text, visible = true) { this.#action.textContent = text; this.#action.hidden = !visible; }
  async fade(direction, ms = 350) {
    const overlay = document.querySelector('#n2-fade') ?? Object.assign(document.createElement('div'), { id: 'n2-fade' });
    if (!overlay.isConnected) this.#root.appendChild(overlay);
    overlay.style.transition = `opacity ${ms}ms linear`; overlay.style.opacity = direction === 'out' ? '0' : '1';
    await new Promise(r => requestAnimationFrame(() => { overlay.style.opacity = direction === 'out' ? '1' : '0'; setTimeout(r, ms); }));
  }
}
