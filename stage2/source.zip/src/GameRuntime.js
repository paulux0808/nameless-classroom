import * as THREE from 'three';
import { EventBus } from './core/EventBus.js';
import { SemanticStore } from './core/SemanticStore.js';
import { LockManager } from './core/LockManager.js';
import { ReservationManager } from './core/ReservationManager.js';
import { OwnershipManager } from './core/OwnershipManager.js';
import { MarkerLedger } from './core/MarkerLedger.js';
import { SequenceRunner } from './core/SequenceRunner.js';
import { RuntimeClock } from './core/RuntimeClock.js';
import { TweenService } from './core/TweenService.js';
import { InputRouter } from './input/InputRouter.js';
import { BrowserInputAdapter } from './input/BrowserInputAdapter.js';
import { PlayerController } from './player/PlayerController.js';
import { CameraRig } from './camera/CameraRig.js';
import { InteractionSystem } from './interaction/InteractionSystem.js';
import { AnchorRegistry } from './world/AnchorRegistry.js';
import { ObjectRegistry } from './world/ObjectRegistry.js';
import { CollisionSystem } from './world/CollisionSystem.js';
import { AssetManager } from './world/AssetManager.js';
import { ObjectMotionSystem } from './world/ObjectMotionSystem.js';
import { NPCSystem } from './npc/NPCSystem.js';
import { NPCGestureSystem } from './npc/NPCGestureSystem.js';
import { DialogueSystem } from './dialogue/DialogueSystem.js';
import { DocumentSystem } from './document/DocumentSystem.js';
import { StampSystem } from './stamp/StampSystem.js';
import { SaveManager } from './save/SaveManager.js';
import { SpoilerGuard } from './spoiler/SpoilerGuard.js';
import { TransitionManager } from './transition/TransitionManager.js';
import { PerformanceManager } from './performance/PerformanceManager.js';
import { MobileControls } from './mobile/MobileControls.js';
import { AudioSystem } from './audio/AudioSystem.js';
import { UISystem } from './ui/UISystem.js';
import { CinematicSystem } from './cinematic/CinematicSystem.js';
import { FacilitySystem } from './facility/FacilitySystem.js';
import { FacilityProgress } from './facility/FacilityProgress.js';
import { LightingSystem } from './lighting/LightingSystem.js';
import { HistoricalRegistry } from './historical/HistoricalRegistry.js';
import { SettingsManager } from './settings/SettingsManager.js';
import { DevInspector } from './debug/DevInspector.js';
import { ChapterRuntime } from './chapter/ChapterRuntime.js';
import { DefaultSave, InputAction, PlayerState } from './constants.js';

export class GameRuntime {
  constructor({ canvas, chapter, dev = false }) {
    this.canvas = canvas; this.chapterDefinition = chapter; this.dev = dev;
    this.isMobile = matchMedia('(pointer: coarse)').matches;
    this.events = new EventBus(); this.store = new SemanticStore(DefaultSave, this.events);
    this.locks = new LockManager(); this.reservations = new ReservationManager(); this.ownership = new OwnershipManager(); this.markers = new MarkerLedger();
    this.clock = new RuntimeClock(); this.tweens = new TweenService(); this.spoiler = new SpoilerGuard({ dev });
    this.input = new InputRouter({ getPlayerState: () => this.player?.state ?? PlayerState.LOCKED, locks: this.locks });
    this.player = new PlayerController({ events: this.events, inputRouter: this.input });
    this.camera = new CameraRig({ player: this.player, tweens: this.tweens });
    this.scene = new THREE.Scene(); this.scene.add(this.player.root);
    this.renderer = new THREE.WebGLRenderer({ canvas, antialias: true, powerPreference: 'high-performance' });
    this.renderer.shadowMap.enabled = true; this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    this.renderer.outputColorSpace = THREE.SRGBColorSpace; this.renderer.toneMapping = THREE.ACESFilmicToneMapping; this.renderer.toneMappingExposure = 1;
    this.anchors = new AnchorRegistry(); this.objects = new ObjectRegistry(); this.collision = new CollisionSystem();
    this.facility = new FacilitySystem({ anchors: this.anchors, collision: this.collision }); this.scene.add(this.facility.root);
    this.assets = new AssetManager({ renderer: this.renderer });
    this.objectMotion = new ObjectMotionSystem({ objects: this.objects, anchors: this.anchors, tweens: this.tweens, scene: this.scene, ownership: this.ownership });
    this.sequences = new SequenceRunner({ locks: this.locks, reservations: this.reservations, ownership: this.ownership, events: this.events });
    this.cinematic = new CinematicSystem({ player: this.player, sequences: this.sequences, events: this.events });
    this.ui = new UISystem(); this.audio = new AudioSystem(); this.audio.attachToCamera(this.camera.camera);
    this.lighting = new LightingSystem(this.scene); this.settings = new SettingsManager();
    this.npcs = new NPCSystem({ anchors: this.anchors, tweens: this.tweens, ownership: this.ownership });
    this.npcGestures = new NPCGestureSystem();
    this.documents = new DocumentSystem({ events: this.events });
    this.historical = new HistoricalRegistry({ spoilerGuard: this.spoiler });
    this.dialogue = new DialogueSystem({ player: this.player, events: this.events, spoilerGuard: this.spoiler, onLine: line => this.ui.setDialogue(line) });
    this.interactions = new InteractionSystem({ camera: this.camera.camera, spoilerGuard: this.spoiler, getContext: () => ({ playerState: this.player.state, story: this.store.state.story, chapterId: this.store.state.chapterId }) });
    this.save = new SaveManager({ events: this.events, validate: data => this.validateSave(data), migrate: (data, target) => this.migrateSave(data, target) });
    this.transition = new TransitionManager({ player: this.player, locks: this.locks, saveManager: this.save, fade: dir => this.ui.fade(dir) });
    this.stamp = new StampSystem({ player: this.player, documents: this.documents, sequences: this.sequences, markers: this.markers, events: this.events, camera: this.camera });
    this.performance = new PerformanceManager({ renderer: this.renderer, mobile: this.isMobile });
    this.facilityProgress = new FacilityProgress(this); this.devInspector = new DevInspector(this);
    this.desktopInput = new BrowserInputAdapter({ router: this.input, canvas }); this.mobileInput = new MobileControls({ router: this.input });
    this.inputAdapter = this.isMobile ? this.mobileInput : this.desktopInput;
    this.chapter = new ChapterRuntime(this, chapter); this.#wireInput();
  }
  async start() {
    this.performance.applyInitial(); this.resize(); addEventListener('resize', this.#onResize); addEventListener('blur', this.#onFocusLoss); document.addEventListener('visibilitychange', this.#onVisibility);
    const entry = await this.chapter.start();
    if (entry?.redirected) return entry;
    this.inputAdapter.enable();
    if (this.player.state === PlayerState.LOCKED) this.player.setState(PlayerState.FREE, 'chapter ready');
    this.devInspector.mount(); this.renderer.setAnimationLoop(this.#loop);
    return entry;
  }
  #wireInput() {
    this.input.on(InputAction.INTERACT, e => { if (this.player.state === PlayerState.FREE && this.interactions.interact()) e.consume(); });
    this.input.on(InputAction.ADVANCE_DIALOGUE, e => { if (this.player.state === PlayerState.DIALOGUE) { this.dialogue.advance(); e.consume(); } });
    this.input.on(InputAction.CONFIRM, e => { if (this.player.state === PlayerState.STAMP) { this.stamp.confirm(); e.consume(); } });
    this.input.on(InputAction.CANCEL, e => { if (this.player.state === PlayerState.STAMP && this.stamp.cancel()) e.consume(); });
  }
  #loop = time => {
    const frame = this.clock.tick(time); this.tweens.updateDelta(frame.delta * 1000); this.npcGestures.update(frame.delta);
    const adapter = this.inputAdapter;
    const movement = adapter.sampleMovement(); const look = adapter.consumeLookDelta();
    if ([PlayerState.FREE, PlayerState.CARRY, PlayerState.FOCUS].includes(this.player.state)) this.camera.applyLook(look);
    this.player.update(frame.delta, movement, this.camera.yaw, this.collision);
    this.chapter.update(frame); this.ui.setInteractionLabel(this.player.state === PlayerState.FREE ? this.interactions.currentLabel() : '');
    this.performance.sample(frame.rawDelta, time); this.devInspector.update(); this.renderer.render(this.scene, this.camera.camera);
  };
  #onResize = () => this.resize();
  #onFocusLoss = () => { this.clock.reset(); this.input.resetTransient(); };
  #onVisibility = () => { if (document.hidden) this.#onFocusLoss(); else this.clock.reset(); };
  resize() { const w = this.canvas.clientWidth || innerWidth, h = this.canvas.clientHeight || innerHeight; this.renderer.setSize(w, h, false); this.camera.resize(w, h); }
  async dispose() {
    this.renderer.setAnimationLoop(null); this.inputAdapter.disable();
    removeEventListener('resize', this.#onResize); removeEventListener('blur', this.#onFocusLoss); document.removeEventListener('visibilitychange', this.#onVisibility);
    await this.chapter.dispose?.(); this.audio.stopAll(); this.npcGestures.clear(); this.lighting.dispose(); this.assets.dispose(); this.facility.clear(); this.renderer.dispose();
  }
  commit(label, mutator, { checkpointId = null, critical = false } = {}) {
    const state = this.store.transaction(label, draft => { mutator(draft); if (checkpointId) draft.checkpointId = checkpointId; });
    const snapshot = this.store.snapshot();
    if (critical) return this.save.save(snapshot, { critical: true });
    this.save.save(snapshot, { critical: false }).catch(error => this.events.emit('save:error', error));
    return state;
  }
  validateSave(data) {
    if (!data || typeof data !== 'object') return false;
    const match = /^CH(\d{2})$/.exec(data.chapterId ?? '');
    if (!match || Number(match[1]) < 1 || Number(match[1]) > 10) return false;
    if (typeof data.checkpointId !== 'string' || !data.checkpointId.length) return false;
    const approved = data.progress?.approvedChapters ?? [];
    if (!Array.isArray(approved) || approved.some((n, i) => n !== i + 1 || n < 1 || n > 8)) return false;
    const fixed = [0, 8, 19, 31, 44, 57, 69, 82, 100];
    if ((data.progress?.facilityPercent ?? 0) !== fixed[approved.length]) return false;
    if (data.archive?.unlocked && Number(match[1]) < 10) return false;
    return true;
  }
  migrateSave(data, target) { return { ...data, saveVersion: target }; }
}
