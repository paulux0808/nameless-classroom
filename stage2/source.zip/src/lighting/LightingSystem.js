import * as THREE from 'three';

export class LightingSystem {
  groups = new Map();
  constructor(scene) { this.scene = scene; }
  group(id) { if (!this.groups.has(id)) { const g = new THREE.Group(); g.name = `LIGHT_GROUP_${id}`; this.groups.set(id, g); this.scene.add(g); } return this.groups.get(id); }
  addAmbient(id, { color = 0xffffff, intensity = 0.25 } = {}) { const l = new THREE.HemisphereLight(color, 0x202020, intensity); this.group(id).add(l); return l; }
  addTask(id, { color = 0xffe7c0, intensity = 2, distance = 5, position = [0, 2, 0], castShadow = false } = {}) { const l = new THREE.PointLight(color, intensity, distance); l.position.fromArray(position); l.castShadow = castShadow; this.group(id).add(l); return l; }
  setGroupEnabled(id, enabled) { const g = this.groups.get(id); if (g) g.visible = enabled; }
  dispose() { for (const g of this.groups.values()) g.removeFromParent(); this.groups.clear(); }
}
