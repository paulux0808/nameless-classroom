import { SpoilerLevel } from '../constants.js';

export const HistoricalLayer = Object.freeze({ FACT: 'HISTORICAL_FACT', DRAMATIZED: 'DRAMATIZED_COMPRESSED_HISTORY', FICTION: 'GAME_FICTION' });

export class HistoricalRegistry {
  #items = new Map(); #spoiler;
  constructor({ spoilerGuard }) { this.#spoiler = spoilerGuard; }
  register(item) {
    if (!item?.id || !Object.values(HistoricalLayer).includes(item.layer)) throw new Error('Historical item requires id and valid layer');
    this.#items.set(item.id, { requiredLevel: SpoilerLevel.LEVEL_3, verificationStatus: 'UNVERIFIED', sources: [], ...item });
  }
  get(id) { const item = this.#items.get(id); if (!item) return null; if (!this.#spoiler.canAccess(item.requiredLevel)) return null; return structuredClone(item); }
  verified(id) { return this.#items.get(id)?.verificationStatus === 'VERIFIED'; }
  list({ layer = null } = {}) { return [...this.#items.values()].filter(x => !layer || x.layer === layer).filter(x => this.#spoiler.canAccess(x.requiredLevel)).map(x => structuredClone(x)); }
}
