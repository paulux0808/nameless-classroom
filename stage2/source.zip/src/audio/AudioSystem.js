import * as THREE from 'three';

export class AudioSystem {
  listener = new THREE.AudioListener();
  #loader = new THREE.AudioLoader(); #buffers = new Map(); #sources = new Map();
  attachToCamera(camera) { camera.add(this.listener); }
  async load(id, url) { if (!this.#buffers.has(id)) this.#buffers.set(id, await this.#loader.loadAsync(url)); return this.#buffers.get(id); }
  createPositional(id, { refDistance = 1, maxDistance = 12, volume = 1 } = {}) {
    const sound = new THREE.PositionalAudio(this.listener); sound.setRefDistance(refDistance); sound.setMaxDistance(maxDistance); sound.setVolume(volume); this.#sources.set(id, sound); return sound;
  }
  play(id, bufferId, { loop = false, volume = 1 } = {}) { const source = this.#sources.get(id); const buffer = this.#buffers.get(bufferId); if (!source || !buffer) return false; if (source.isPlaying) source.stop(); source.setBuffer(buffer); source.setLoop(loop); source.setVolume(volume); source.play(); return true; }
  stopAll() { for (const source of this.#sources.values()) if (source.isPlaying) source.stop(); }
}
