import { get, set } from 'idb-keyval';

export class SettingsManager {
  #key; #defaults;
  constructor({ key = 'nameless2.settings', defaults = { settingsVersion: 1, masterVolume: 1, subtitles: true, quality: 'AUTO', sensitivity: 1 } } = {}) { this.#key = key; this.#defaults = defaults; }
  async load() { return { ...this.#defaults, ...(await get(this.#key) ?? {}) }; }
  async save(settings) { await set(this.#key, { ...this.#defaults, ...settings }); }
}
