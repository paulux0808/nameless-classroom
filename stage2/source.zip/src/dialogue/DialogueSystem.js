import { PlayerState } from '../constants.js';

export class DialogueSystem {
  #player; #events; #spoiler; #active = null; #advanceAllowed = false; #onLine; #autoTimer = null;
  constructor({ player, events, spoilerGuard, onLine }) { this.#player = player; this.#events = events; this.#spoiler = spoilerGuard; this.#onLine = onLine; }
  get active() { return this.#active; }
  async start(dialogue, { startIndex = 0 } = {}) {
    if (this.#active) throw new Error('Dialogue already active');
    this.#clearAuto();
    this.#player.setState(PlayerState.DIALOGUE, `dialogue:${dialogue.id}`);
    this.#active = { dialogue, index: startIndex };
    await this.#showCurrent();
  }
  async #showCurrent() {
    this.#clearAuto();
    const line = this.#active?.dialogue.lines[this.#active.index];
    if (!line) return this.finish();
    this.#advanceAllowed = false;
    const safe = {
      ...line,
      speaker: this.#spoiler.safeText(line.speaker ?? '', line.speakerRequiredLevel ?? line.requiredLevel ?? 0),
      text: this.#spoiler.safeText(line.text, line.requiredLevel ?? 0),
    };
    await this.#onLine?.(safe);
    if (!this.#active) return;
    this.#advanceAllowed = true;
    this.#events?.emit('dialogue:line', { dialogueId: this.#active.dialogue.id, lineId: line.id, index: this.#active.index });
    if (line.mode === 'AUTO') {
      const dialogueId = this.#active.dialogue.id;
      const index = this.#active.index;
      this.#autoTimer = setTimeout(() => {
        if (this.#active?.dialogue.id === dialogueId && this.#active.index === index) this.advance();
      }, line.autoMs ?? 1800);
    }
  }
  async advance() {
    if (!this.#active || !this.#advanceAllowed) return false;
    this.#clearAuto();
    this.#advanceAllowed = false;
    this.#active.index += 1;
    await this.#showCurrent();
    return true;
  }
  finish(nextState = PlayerState.FREE) {
    this.#clearAuto();
    const ended = this.#active; this.#active = null; this.#advanceAllowed = false;
    this.#player.setState(nextState, 'dialogue:end'); this.#events?.emit('dialogue:end', { dialogueId: ended?.dialogue.id });
  }
  checkpoint() { return this.#active ? { dialogueId: this.#active.dialogue.id, lineId: this.#active.dialogue.lines[this.#active.index]?.id ?? null } : null; }
  #clearAuto() { if (this.#autoTimer != null) clearTimeout(this.#autoTimer); this.#autoTimer = null; }
}
