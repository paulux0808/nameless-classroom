import { clamp } from '../core/assert.js';

export class PerformanceManager {
  profile = 'HIGH';
  targetFps;
  maxDpr;
  #renderer; #samples = []; #lastAdjust = 0; #degradation = []; #stage = 0;
  constructor({ renderer, mobile = false }) {
    this.#renderer = renderer;
    this.targetFps = mobile ? 30 : 60;
    this.maxDpr = mobile ? 1.5 : 2;
  }
  applyInitial() { this.#renderer.setPixelRatio(Math.min(devicePixelRatio || 1, this.maxDpr)); }
  registerDegradationStep({ id, degrade, restore }) {
    this.#degradation.push({ id, degrade, restore });
    return () => { this.#degradation = this.#degradation.filter(x => x.id !== id); };
  }
  sample(rawDelta, now = performance.now()) {
    if (!rawDelta || rawDelta > 1) return;
    this.#samples.push(1 / rawDelta); if (this.#samples.length > 120) this.#samples.shift();
    if (now - this.#lastAdjust < 3000 || this.#samples.length < 60) return;
    this.#lastAdjust = now;
    const fps = this.#samples.reduce((a, b) => a + b, 0) / this.#samples.length;
    const dpr = this.#renderer.getPixelRatio();
    if (fps < this.targetFps * 0.82) {
      if (dpr > 0.75) this.#renderer.setPixelRatio(clamp(dpr - 0.2, 0.75, this.maxDpr));
      else if (this.#stage < this.#degradation.length) this.#degradation[this.#stage++]?.degrade?.();
    } else if (fps > this.targetFps * 0.98) {
      if (this.#stage > 0) this.#degradation[--this.#stage]?.restore?.();
      else if (dpr < this.maxDpr) this.#renderer.setPixelRatio(clamp(dpr + 0.1, 0.75, this.maxDpr));
    }
  }
  setProfile(profile) { this.profile = profile; }
  get degradationStage() { return this.#stage; }
}
