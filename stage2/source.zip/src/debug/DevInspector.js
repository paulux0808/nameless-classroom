export class DevInspector {
  #game; #el;
  constructor(game) { this.#game = game; }
  mount() {
    if (!this.#game.dev || this.#el) return;
    this.#el = document.createElement('pre'); this.#el.id = 'n2-dev'; document.body.appendChild(this.#el);
  }
  update() {
    if (!this.#el) return;
    const safe = {
      playerState: this.#game.player.state,
      chapterId: this.#game.store.state.chapterId,
      checkpointId: this.#game.store.state.checkpointId,
      facilityPercent: this.#game.store.state.progress?.facilityPercent,
      spoilerLevel: this.#game.spoiler.level,
      cinematic: this.#game.cinematic?.activeId ?? null,
      stamp: this.#game.stamp.active?.sequenceId ?? null,
    };
    this.#el.textContent = JSON.stringify(safe, null, 2);
  }
}
