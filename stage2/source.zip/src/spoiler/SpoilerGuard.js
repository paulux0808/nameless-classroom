import { SpoilerLevel } from '../constants.js';

const LEVEL0_FORBIDDEN = [
  /atomic bomb/ig, /nuclear bomb/ig, /\bbomb\b/ig, /detonator/ig, /detonation/ig,
  /implosion lens/ig, /explosive lens/ig, /fat man/ig, /little boy/ig, /trinity/ig,
  /hiroshima/ig, /nagasaki/ig, /manhattan project/ig, /oppenheimer/ig,
];

export class SpoilerGuard {
  level = SpoilerLevel.LEVEL_0;
  dev = false;
  constructor({ level = 0, dev = false } = {}) { this.level = level; this.dev = dev; }
  setLevel(level) { if (level < this.level) throw new Error('Spoiler level cannot move backwards during a live session'); this.level = level; }
  canAccess(requiredLevel = 0) { return this.level >= requiredLevel; }
  safeText(text, requiredLevel = 0) {
    if (!this.canAccess(requiredLevel)) return 'REDACTED';
    const value = String(text ?? '');
    if (this.level === SpoilerLevel.LEVEL_0) {
      const hit = LEVEL0_FORBIDDEN.find(rx => (rx.lastIndex = 0, rx.test(value)));
      if (hit) {
        if (this.dev) throw new Error(`LEVEL 0 spoiler text blocked: ${value}`);
        return 'REDACTED';
      }
    }
    return value;
  }
  expose(value, requiredLevel, fallback = 'UNKNOWN') { return this.canAccess(requiredLevel) ? value : fallback; }
  assertAsset(descriptor) {
    if ((descriptor?.spoilerLevel ?? 0) > this.level) {
      if (this.dev) throw new Error(`Spoiler-gated asset requested: ${descriptor?.id ?? 'unknown'}`);
      return false;
    }
    return true;
  }
}
