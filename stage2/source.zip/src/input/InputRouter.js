import { PlayerState, InputAction } from '../constants.js';

const allowedByState = {
  [PlayerState.FREE]: new Set(Object.values(InputAction)),
  [PlayerState.FOCUS]: new Set([InputAction.LOOK_DELTA, InputAction.INTERACT, InputAction.CONFIRM, InputAction.CANCEL, InputAction.PAUSE, InputAction.FULLSCREEN]),
  [PlayerState.DIALOGUE]: new Set([InputAction.ADVANCE_DIALOGUE, InputAction.CONFIRM, InputAction.PAUSE, InputAction.FULLSCREEN]),
  [PlayerState.INSPECT]: new Set([InputAction.INSPECT_ROTATE, InputAction.INSPECT_FLIP, InputAction.CONFIRM, InputAction.CANCEL, InputAction.PAUSE, InputAction.FULLSCREEN]),
  [PlayerState.CARRY]: new Set([InputAction.MOVE_FORWARD, InputAction.MOVE_BACK, InputAction.MOVE_LEFT, InputAction.MOVE_RIGHT, InputAction.LOOK_DELTA, InputAction.CARRY_DROP, InputAction.INTERACT, InputAction.PAUSE, InputAction.FULLSCREEN]),
  [PlayerState.STAMP]: new Set([InputAction.CONFIRM, InputAction.CANCEL, InputAction.PAUSE, InputAction.FULLSCREEN]),
  [PlayerState.CINEMATIC]: new Set([InputAction.CONFIRM, InputAction.PAUSE, InputAction.FULLSCREEN]),
  [PlayerState.LOCKED]: new Set([InputAction.PAUSE, InputAction.FULLSCREEN]),
  [PlayerState.TRANSITION]: new Set([InputAction.FULLSCREEN]),
};

export class InputRouter {
  #getState; #locks; #handlers = new Map(); #generation = 0; #blockedUntilRelease = new Set();
  constructor({ getPlayerState, locks }) { this.#getState = getPlayerState; this.#locks = locks; }
  on(action, handler) { const set = this.#handlers.get(action) ?? new Set(); set.add(handler); this.#handlers.set(action, set); return () => set.delete(handler); }
  dispatchPrimary(payload = {}) {
    const state = this.#getState();
    const action = state === PlayerState.DIALOGUE ? InputAction.ADVANCE_DIALOGUE
      : state === PlayerState.STAMP || state === PlayerState.INSPECT || state === PlayerState.CINEMATIC ? InputAction.CONFIRM
      : InputAction.INTERACT;
    return this.dispatch(action, payload);
  }
  dispatch(action, payload = {}) {
    if (this.#blockedUntilRelease.has(action)) return false;
    const state = this.#getState();
    if (!allowedByState[state]?.has(action)) return false;
    if (this.#locks.isLocked('PLAYER_INPUT') && ![InputAction.PAUSE, InputAction.FULLSCREEN].includes(action)) return false;
    const event = { action, payload, state, generation: this.#generation, consumed: false, consume() { this.consumed = true; } };
    for (const fn of [...(this.#handlers.get(action) ?? [])]) { fn(event); if (event.consumed) break; }
    return event.consumed;
  }
  consumeUntilRelease(action) { this.#blockedUntilRelease.add(action); }
  release(action) { this.#blockedUntilRelease.delete(action); this.#generation += 1; }
  resetTransient() { this.#blockedUntilRelease.clear(); this.#generation += 1; }
}
