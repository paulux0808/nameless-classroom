import { InputAction } from '../constants.js';

export class BrowserInputAdapter {
  #router; #keys = new Set(); #look = { x: 0, y: 0 }; #enabled = false; #canvas;
  #dragPointerId = null; #lastPointer = { x: 0, y: 0 }; #dragDistance = 0;
  constructor({ router, canvas }) { this.#router = router; this.#canvas = canvas; }
  enable() {
    if (this.#enabled) return; this.#enabled = true;
    addEventListener('keydown', this.#onKeyDown);
    addEventListener('keyup', this.#onKeyUp);
    addEventListener('blur', this.#reset);
    document.addEventListener('visibilitychange', this.#onVisibility);
    this.#canvas.addEventListener('pointerdown', this.#onPointerDown);
    this.#canvas.addEventListener('pointerup', this.#onPointerUp);
    this.#canvas.addEventListener('pointercancel', this.#onPointerUp);
    this.#canvas.addEventListener('pointermove', this.#onPointerMove);
  }
  disable() {
    if (!this.#enabled) return; this.#enabled = false;
    removeEventListener('keydown', this.#onKeyDown);
    removeEventListener('keyup', this.#onKeyUp);
    removeEventListener('blur', this.#reset);
    document.removeEventListener('visibilitychange', this.#onVisibility);
    this.#canvas.removeEventListener('pointerdown', this.#onPointerDown);
    this.#canvas.removeEventListener('pointerup', this.#onPointerUp);
    this.#canvas.removeEventListener('pointercancel', this.#onPointerUp);
    this.#canvas.removeEventListener('pointermove', this.#onPointerMove);
    this.#reset();
  }
  sampleMovement() {
    return {
      forward: Number(this.#keys.has('KeyW')) - Number(this.#keys.has('KeyS')),
      right: Number(this.#keys.has('KeyD')) - Number(this.#keys.has('KeyA')),
    };
  }
  consumeLookDelta() { const v = { ...this.#look }; this.#look.x = this.#look.y = 0; return v; }
  #onKeyDown = e => {
    if (e.repeat) return;
    this.#keys.add(e.code);
    const map = { KeyE: InputAction.INTERACT, Space: InputAction.ADVANCE_DIALOGUE, Escape: InputAction.CANCEL, Enter: InputAction.CONFIRM };
    const action = map[e.code]; if (action) this.#router.dispatch(action, { originalEvent: e });
  };
  #onKeyUp = e => {
    this.#keys.delete(e.code);
    this.#router.release(InputAction.INTERACT);
    this.#router.release(InputAction.CONFIRM);
    this.#router.release(InputAction.ADVANCE_DIALOGUE);
  };
  #onPointerDown = e => {
    if (e.button !== 0) return;
    this.#dragPointerId = e.pointerId; this.#lastPointer = { x: e.clientX, y: e.clientY }; this.#dragDistance = 0;
    this.#canvas.setPointerCapture?.(e.pointerId);
  };
  #onPointerUp = e => {
    if (e.pointerId === this.#dragPointerId) {
      if (e.type !== 'pointercancel' && this.#dragDistance < 7) this.#router.dispatchPrimary({ originalEvent: e, pointerId: e.pointerId });
      this.#canvas.releasePointerCapture?.(e.pointerId);
      this.#dragPointerId = null; this.#dragDistance = 0;
    }
    this.#router.release(InputAction.INTERACT);
    this.#router.release(InputAction.CONFIRM);
    this.#router.release(InputAction.ADVANCE_DIALOGUE);
  };
  #onPointerMove = e => {
    if (document.pointerLockElement === this.#canvas) {
      this.#look.x += e.movementX; this.#look.y += e.movementY; return;
    }
    if (e.pointerId !== this.#dragPointerId) return;
    const dx = e.clientX - this.#lastPointer.x, dy = e.clientY - this.#lastPointer.y;
    this.#lastPointer = { x: e.clientX, y: e.clientY };
    this.#dragDistance += Math.abs(dx) + Math.abs(dy);
    this.#look.x += dx; this.#look.y += dy;
  };
  #onVisibility = () => { if (document.hidden) this.#reset(); };
  #reset = () => { this.#keys.clear(); this.#look.x = this.#look.y = 0; this.#dragPointerId = null; this.#dragDistance = 0; this.#router.resetTransient(); };
}
