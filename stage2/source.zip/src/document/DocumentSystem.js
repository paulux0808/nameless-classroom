import { StampType } from '../constants.js';
import { invariant } from '../core/assert.js';

export class DocumentSystem {
  #docs = new Map(); #events;
  constructor({ events }) { this.#events = events; }
  register(def) {
    invariant(def?.id, 'Document requires id');
    invariant(!this.#docs.has(def.id), `Duplicate document: ${def.id}`);
    const doc = {
      id: def.id,
      logicalStatus: def.logicalStatus ?? 'DRAFT',
      revision: def.revision ?? 0,
      archiveStatus: def.archiveStatus ?? 'NONE',
      side: def.side ?? 'FRONT',
      page: def.page ?? 0,
      stampType: def.stampType ?? null,
      stampable: def.stampable ?? false,
      metadata: def.metadata ?? {},
      objectId: def.objectId ?? null,
    };
    this.#docs.set(doc.id, doc); return doc;
  }
  get(id) { return this.#docs.get(id) ?? null; }
  require(id) { const doc = this.get(id); invariant(doc, `Missing document: ${id}`); return doc; }
  setStampable(id, value) { this.require(id).stampable = Boolean(value); }
  recordStamp(id, type) {
    invariant(Object.values(StampType).includes(type), `Invalid stamp type: ${type}`);
    const doc = this.require(id); doc.stampType = type; doc.logicalStatus = type;
    this.#events?.emit('document:stamped', { id, type }); return doc;
  }
  setRevision(id, revision) { this.require(id).revision = revision; }
  replaceState(id, state) { const doc = this.require(id); const immutableId = doc.id; Object.assign(doc, structuredClone(state), { id: immutableId }); return doc; }
  snapshot() { return Object.fromEntries([...this.#docs].map(([id, d]) => [id, structuredClone(d)])); }
  restore(map = {}) { for (const [id, state] of Object.entries(map)) if (this.#docs.has(id)) Object.assign(this.#docs.get(id), structuredClone(state)); }
}
