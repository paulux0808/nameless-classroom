import * as THREE from 'three';
import { clamp } from '../core/assert.js';

export class CameraRig {
  root = new THREE.Object3D();
  camera;
  yaw = 0; pitch = 0;
  #tweens; #player;
  constructor({ player, tweens, fov = 70, near = 0.05, far = 150 }) {
    this.#player = player; this.#tweens = tweens;
    this.camera = new THREE.PerspectiveCamera(fov, 1, near, far);
    this.camera.position.set(0, player.eyeHeight, 0);
    this.root.add(this.camera); player.root.add(this.root);
  }
  resize(w, h) { this.camera.aspect = w / Math.max(1, h); this.camera.updateProjectionMatrix(); }
  applyLook(delta, sensitivity = 0.002) {
    this.yaw += delta.x * sensitivity; this.pitch = clamp(this.pitch + delta.y * sensitivity, -1.35, 1.35);
    this.root.rotation.y = this.yaw; this.camera.rotation.x = this.pitch;
  }
  async moveLocalTo({ position, rotation, fov }, options = {}) {
    const jobs = [];
    if (position) jobs.push(this.#tweens.to(this.camera.position, position, options));
    if (rotation) jobs.push(this.#tweens.to(this.camera.rotation, rotation, options));
    if (fov != null) jobs.push(this.#tweens.to(this.camera, { fov }, { ...options, onUpdate: () => this.camera.updateProjectionMatrix() }));
    await Promise.all(jobs);
  }
  isSafePose() { return Number.isFinite(this.camera.position.x + this.camera.position.y + this.camera.position.z); }
}
