import * as THREE from 'three';
import { invariant } from '../core/assert.js';

export class AnchorRegistry {
  #anchors = new Map();
  register(id, object3D = new THREE.Object3D(), meta = {}) { invariant(!this.#anchors.has(id), `Duplicate anchor: ${id}`); object3D.name ||= id; this.#anchors.set(id, { id, object3D, meta }); return object3D; }
  get(id) { return this.#anchors.get(id)?.object3D ?? null; }
  require(id) { const a = this.get(id); invariant(a, `Missing anchor: ${id}`); return a; }
  worldPose(id) { const a = this.require(id); return { position: a.getWorldPosition(new THREE.Vector3()), quaternion: a.getWorldQuaternion(new THREE.Quaternion()) }; }
  clear() { this.#anchors.clear(); }
}
