import * as THREE from 'three';
import { invariant } from '../core/assert.js';

export class ObjectMotionSystem {
  #objects; #anchors; #tweens; #scene; #ownership;
  constructor({ objects, anchors, tweens, scene, ownership }) { this.#objects = objects; this.#anchors = anchors; this.#tweens = tweens; this.#scene = scene; this.#ownership = ownership; }
  attachPreserveWorld(objectId, parent) {
    const object = this.#objects.object(objectId); invariant(object, `Missing object: ${objectId}`); parent.attach(object); return object;
  }
  detachToScene(objectId) { return this.attachPreserveWorld(objectId, this.#scene); }
  async moveToAnchor(objectId, anchorId, { duration = 450, owner = 'OBJECT_MOTION', priority = 30, signal, position = true, rotation = true } = {}) {
    const object = this.#objects.object(objectId); invariant(object, `Missing object: ${objectId}`);
    const anchor = this.#anchors.require(anchorId);
    if (!this.#ownership.claim(objectId, owner, priority)) return false;
    const targetPosition = anchor.getWorldPosition(new THREE.Vector3());
    const targetQuaternion = anchor.getWorldQuaternion(new THREE.Quaternion());
    try {
      const jobs = [];
      if (position) jobs.push(this.#tweens.to(object.position, { x: targetPosition.x, y: targetPosition.y, z: targetPosition.z }, { duration, signal }));
      if (rotation) {
        const state = { t: 0 }; const start = object.quaternion.clone();
        jobs.push(this.#tweens.to(state, { t: 1 }, { duration, signal, onUpdate: () => object.quaternion.slerpQuaternions(start, targetQuaternion, state.t) }));
      }
      await Promise.all(jobs); return true;
    } finally { this.#ownership.release(objectId, owner); }
  }
  applyCanonical(objectId, state) {
    const object = this.#objects.object(objectId); invariant(object, `Missing object: ${objectId}`);
    if (state.parentObjectId) {
      const parent = this.#objects.object(state.parentObjectId); invariant(parent, `Missing parent object: ${state.parentObjectId}`); parent.attach(object);
    } else if (state.parent === 'SCENE') this.#scene.attach(object);
    if (state.position) object.position.fromArray(state.position);
    if (state.quaternion) object.quaternion.fromArray(state.quaternion);
    if (state.scale) object.scale.fromArray(state.scale);
    object.visible = state.visible ?? object.visible;
    object.updateMatrixWorld(true);
  }
}
