import * as THREE from 'three';

export class CollisionSystem {
  #boxes = []; #testBox = new THREE.Box3(); #min = new THREE.Vector3(); #max = new THREE.Vector3(); #xOnly = new THREE.Vector3(); #zOnly = new THREE.Vector3();
  playerRadius = 0.28; playerHeight = 1.8;
  addBox(boxOrObject, padding = 0) {
    const box = boxOrObject instanceof THREE.Box3 ? boxOrObject.clone() : new THREE.Box3().setFromObject(boxOrObject);
    if (padding) box.expandByScalar(padding); this.#boxes.push(box); return box;
  }
  clear() { this.#boxes.length = 0; }
  #blocked(p) {
    this.#min.set(p.x - this.playerRadius, p.y, p.z - this.playerRadius);
    this.#max.set(p.x + this.playerRadius, p.y + this.playerHeight, p.z + this.playerRadius);
    this.#testBox.set(this.#min, this.#max);
    return this.#boxes.some(b => b.intersectsBox(this.#testBox));
  }
  resolvePlayerPosition(current, desired) {
    if (!this.#blocked(desired)) return desired;
    this.#xOnly.set(desired.x, desired.y, current.z); if (!this.#blocked(this.#xOnly)) return this.#xOnly;
    this.#zOnly.set(current.x, desired.y, desired.z); if (!this.#blocked(this.#zOnly)) return this.#zOnly;
    return current;
  }
  isSweepClear(box) { return !this.#boxes.some(b => b.intersectsBox(box)); }
}
