import test from 'node:test';
import assert from 'node:assert/strict';
import { EventBus } from '../src/core/EventBus.js';
import { SemanticStore } from '../src/core/SemanticStore.js';
import { LockManager } from '../src/core/LockManager.js';
import { ReservationManager } from '../src/core/ReservationManager.js';
import { OwnershipManager } from '../src/core/OwnershipManager.js';
import { MarkerLedger } from '../src/core/MarkerLedger.js';
import { SequenceRunner } from '../src/core/SequenceRunner.js';
import { SpoilerGuard } from '../src/spoiler/SpoilerGuard.js';
import { SpoilerLevel } from '../src/constants.js';

test('semantic store commits atomically', () => {
  const events = new EventBus(); let commits = 0; events.on('semantic:commit', () => commits++);
  const store = new SemanticStore({ value: 1 }, events);
  store.transaction('inc', s => s.value++);
  assert.equal(store.state.value, 2); assert.equal(commits, 1);
});

test('locks prevent different owner overlap', () => {
  const locks = new LockManager(); const a = locks.acquire('CAMERA', 'A');
  assert.ok(a); assert.equal(locks.acquire('CAMERA', 'B'), null); locks.release(a); assert.ok(locks.acquire('CAMERA', 'B'));
});

test('reservations roll back partial acquisition', () => {
  const r = new ReservationManager(); assert.ok(r.reserve('desk', 'A'));
  assert.equal(r.reserveMany(['slot', 'desk'], 'B'), false); assert.equal(r.ownerOf('slot'), null);
});

test('ownership requires higher priority takeover', () => {
  const o = new OwnershipManager(); assert.ok(o.claim('npc', 'IDLE', 10));
  assert.equal(o.claim('npc', 'DIALOGUE', 40), false); assert.ok(o.claim('npc', 'DIALOGUE', 40, { takeover: true }));
});

test('marker fires once', () => {
  const m = new MarkerLedger(); let count = 0; m.fireOnce('SEQ', 'STAMP_IMPACT', () => count++); m.fireOnce('SEQ', 'STAMP_IMPACT', () => count++); assert.equal(count, 1);
});

test('sequence only commits after verify', async () => {
  const events = new EventBus(); const locks = new LockManager(); const reservations = new ReservationManager(); const ownership = new OwnershipManager();
  const runner = new SequenceRunner({ locks, reservations, ownership, events }); let committed = false;
  await runner.run({ id: 'S', validate: () => true, play: async () => {}, verify: () => true, commit: () => { committed = true; } });
  assert.equal(committed, true);
});

test('sequence rollback on verify failure', async () => {
  const runner = new SequenceRunner({ locks: new LockManager(), reservations: new ReservationManager(), ownership: new OwnershipManager(), events: new EventBus() });
  let rolled = false;
  await assert.rejects(() => runner.run({ id: 'F', play: async () => {}, verify: () => false, rollback: () => { rolled = true; } }));
  assert.equal(rolled, true);
});

test('level 0 spoiler guard blocks direct forbidden term', () => {
  const guard = new SpoilerGuard({ level: SpoilerLevel.LEVEL_0 });
  assert.equal(guard.safeText('Manhattan Project'), 'REDACTED');
  assert.equal(guard.safeText('Calculation Sheet'), 'Calculation Sheet');
});

import { InputRouter } from '../src/input/InputRouter.js';
import { InputAction, PlayerState } from '../src/constants.js';

test('reentrant locks by same owner release independently', () => {
  const locks = new LockManager();
  const a = locks.acquire('CAMERA', 'SEQ');
  const b = locks.acquire('CAMERA', 'SEQ');
  assert.ok(a && b); locks.release(a); assert.equal(locks.ownerOf('CAMERA'), 'SEQ');
  locks.release(b); assert.equal(locks.ownerOf('CAMERA'), null);
});

test('ownership takeover restores suspended owner', () => {
  const o = new OwnershipManager();
  assert.ok(o.claim('npc', 'TASK', 20));
  assert.ok(o.claim('npc', 'CINE', 70, { takeover: true }));
  assert.equal(o.ownerOf('npc'), 'CINE');
  o.release('npc', 'CINE');
  assert.equal(o.ownerOf('npc'), 'TASK');
});

test('primary activation maps to one state-specific action', () => {
  let state = PlayerState.FREE;
  const router = new InputRouter({ getPlayerState: () => state, locks: new LockManager() });
  const seen = [];
  for (const action of [InputAction.INTERACT, InputAction.ADVANCE_DIALOGUE, InputAction.CONFIRM]) {
    router.on(action, e => { seen.push(action); e.consume(); });
  }
  router.dispatchPrimary();
  state = PlayerState.DIALOGUE; router.dispatchPrimary();
  state = PlayerState.STAMP; router.dispatchPrimary();
  assert.deepEqual(seen, [InputAction.INTERACT, InputAction.ADVANCE_DIALOGUE, InputAction.CONFIRM]);
});

import { StoryTimeline } from '../src/core/StoryTimeline.js';

test('story timeline catches up at most one marker per update', () => {
  const ledger = new MarkerLedger(); const seen = [];
  const tl = new StoryTimeline({ id: 'TL', ledger, markers: [
    { id: 'A', atMs: 100, run: () => seen.push('A') },
    { id: 'B', atMs: 200, run: () => seen.push('B') },
    { id: 'C', atMs: 300, run: () => seen.push('C') },
  ] }).start();
  tl.update(1.0); assert.deepEqual(seen, ['A']);
  tl.update(0); assert.deepEqual(seen, ['A', 'B']);
  tl.update(0); assert.deepEqual(seen, ['A', 'B', 'C']);
});

import * as THREE from 'three';
import { CameraRig } from '../src/camera/CameraRig.js';
import { TweenService } from '../src/core/TweenService.js';

test('drag look follows the grabbed view on both axes', () => {
  const player = { eyeHeight: 1.65, root: new THREE.Object3D() };
  const camera = new CameraRig({ player, tweens: new TweenService() });
  camera.applyLook({ x: 20, y: 10 }, 0.01);
  assert.equal(camera.yaw, 0.2);
  assert.equal(camera.pitch, 0.1);
});
