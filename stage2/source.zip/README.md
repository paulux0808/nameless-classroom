# NAMELESS2 Master Runtime

This directory is the reusable master source for building each NAMELESS2 chapter as a single standalone HTML file.

## Contract

The runtime follows the uploaded project specifications:

- semantic story/world state is the source of truth;
- physical animation is a presentation of state transition, not the state itself;
- important animation uses VALIDATE → RESERVE → LOCK → PREPARE → PLAY → VERIFY → COMMIT → RELEASE;
- markers such as STAMP_IMPACT are distinct from final story COMMIT;
- reload reconstructs a canonical endpoint from checkpoint/semantic state rather than restoring transient transforms;
- input is routed centrally by player state;
- one raw activation must not leak into multiple gameplay actions;
- spoiler level gates all user-facing information;
- runtime uses one global renderer animation loop;
- chapter assets are scoped per chapter;
- mobile changes input surface/framing, not puzzle or story logic.

## Source layout

`src/core/` semantic store, events, locks, reservations, ownership, markers, sequences, wall-clock/tween services  
`src/input/` central input router and desktop adapter  
`src/mobile/` pointerId-based mobile control surface  
`src/player/`, `src/camera/`, `src/interaction/` first-person runtime  
`src/world/`, `src/facility/`, `src/lighting/` physical world and authored spatial systems  
`src/npc/`, `src/dialogue/`, `src/document/`, `src/stamp/`, `src/cinematic/` narrative interaction systems  
`src/save/`, `src/transition/`, `src/spoiler/`, `src/historical/` persistence/reveal contracts  
`src/performance/`, `src/audio/`, `src/ui/`, `src/settings/`, `src/debug/` platform support  
`chapters/` chapter-only content/data/sequence definitions  
`tools/build-chapter.mjs` bundles a chapter and all master code into one HTML file

`MASTER_CONTRACT.md` maps the uploaded specification set to runtime modules and invariants.
`SOURCE_RESEARCH.md` records the open-source adoption decisions.
`OFFLINE_BUILD.md` defines offline/single-HTML verification rules.

## Development setup

Dependencies are pinned in `package.json`. They are normal open-source packages and can be cached/vendor-installed locally. Internet access is not required by a built chapter.

```sh
npm install
npm test
npm run check
npm run audit:ch01
npm run build:ch01
npm run check:offline
```

The produced `dist/chapter01.html` contains its JavaScript/CSS runtime directly inside the HTML. PNG/JPEG/WebP/SVG/GLB/BIN/MP3/OGG/WAV files imported by chapter source are configured to be embedded as data URLs, enabling truly single-file builds when desired. Large assets may instead remain local files, but they must never be fetched from a CDN at runtime.

## Building another chapter

Create `chapters/ch02/index.js` that imports `GameRuntime` and defines only CH02-specific scene/content/reconstruction/sequences. Then:

```sh
node tools/build-chapter.mjs chapters/ch02/index.js dist/chapter02.html
# Development build with runtime diagnostics enabled:
node tools/build-chapter.mjs chapters/ch02/index.js dist/chapter02.dev.html --dev
```

Do not copy an older chapter's engine implementation and modify it independently. Change the master runtime first, then rebuild the affected chapter HTML so all copied/bundled common systems stay synchronized.

## CH01 stub

`chapters/ch01/index.js` is intentionally a graybox boot stub. It proves the master runtime entry shape but does not invent the final calculation puzzle values, document copy, dialogue, coordinates, or historical details that the uploaded specifications leave unresolved.
